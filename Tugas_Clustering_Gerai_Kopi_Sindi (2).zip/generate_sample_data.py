"""
Script untuk membuat data contoh (dummy) lokasi gerai kopi.
Jalankan sekali untuk menghasilkan sample_data.csv, atau langsung
gunakan file sample_data.csv yang sudah disediakan.

Ganti pusat koordinat (CENTER_LAT, CENTER_LON) sesuai kota target,
atau langsung pakai data asli kamu dengan format kolom yang sama:
nama, latitude, longitude
"""

import numpy as np
import pandas as pd

np.random.seed(42)

# Pusat kota contoh: Medan, Sumatera Utara
CENTER_LAT = 3.5952
CENTER_LON = 98.6722

N_GERAI = 120

nama_gerai = [f"Gerai Kopi {i+1}" for i in range(N_GERAI)]

# Simulasikan beberapa area "ramai" (padat gerai) dan sisanya tersebar acak (berpotensi sepi)
cluster_centers = [
    (CENTER_LAT + 0.01, CENTER_LON + 0.01),
    (CENTER_LAT - 0.015, CENTER_LON + 0.02),
    (CENTER_LAT + 0.02, CENTER_LON - 0.015),
]

lat_list, lon_list = [], []
for i in range(N_GERAI):
    if i < N_GERAI * 0.7:
        # 70% data mengumpul di sekitar salah satu pusat keramaian
        cx, cy = cluster_centers[i % len(cluster_centers)]
        lat_list.append(cx + np.random.normal(0, 0.004))
        lon_list.append(cy + np.random.normal(0, 0.004))
    else:
        # 30% data tersebar acak lebih jauh (kandidat zona sepi)
        lat_list.append(CENTER_LAT + np.random.uniform(-0.05, 0.05))
        lon_list.append(CENTER_LON + np.random.uniform(-0.05, 0.05))

df = pd.DataFrame({
    "nama": nama_gerai,
    "latitude": lat_list,
    "longitude": lon_list,
})

df.to_csv("sample_data.csv", index=False)
print("sample_data.csv berhasil dibuat dengan", len(df), "baris data.")
