# Analisis Klaster Lokasi Gerai Kopi dan Deteksi Zona Sepi

**Nama:** Sindi Putri Diani
**NIM:** 23146035

## Penjelasan Proyek

Proyek ini menggunakan metode *clustering* **K-Means** untuk menganalisis
persebaran lokasi gerai kopi berdasarkan koordinat geografis (*latitude* dan
*longitude*). Hasil clustering digunakan untuk mengelompokkan gerai ke dalam
beberapa klaster wilayah, kemudian setiap klaster diklasifikasikan sebagai:

- **Zona Ramai** — klaster dengan jumlah gerai kopi di atas ambang batas
  tertentu (kepadatan gerai tinggi).
- **Zona Sepi** — klaster dengan jumlah gerai kopi di bawah ambang batas
  (kepadatan gerai rendah / berisiko sepi pelanggan atau kompetitor).

Aplikasi ini juga memungkinkan pengguna memasukkan koordinat lokasi baru,
lalu sistem akan memprediksi klaster terdekat dan status zona (ramai/sepi)
dari lokasi tersebut menggunakan model K-Means yang sudah dilatih.

## Fitur

1. Upload dataset gerai kopi (CSV: `nama, latitude, longitude`) atau gunakan
   data contoh (`sample_data.csv`) bawaan aplikasi.
2. Pengaturan jumlah klaster (K) dan ambang batas zona sepi secara interaktif.
3. Visualisasi klaster pada peta interaktif (OpenStreetMap) dan scatter plot
   latitude vs longitude, dengan warna berbeda untuk tiap klaster.
4. Ringkasan jumlah gerai dan status tiap klaster.
5. Form input lokasi baru untuk memprediksi klaster & status zona
   (ramai/sepi) secara langsung.

## Instruksi Menjalankan Aplikasi

### 1. Clone repository
```bash
git clone <URL_REPOSITORY_GITHUB_KAMU>
cd <NAMA_FOLDER_REPO>
```

### 2. Buat virtual environment (opsional tapi disarankan)
```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. (Opsional) Buat ulang data contoh
```bash
python generate_sample_data.py
```

### 5. Jalankan aplikasi
```bash
streamlit run app.py
```

Aplikasi akan terbuka otomatis di browser pada `http://localhost:8501`.

## Deploy ke Streamlit Cloud

1. Push repository ini ke GitHub (pastikan `app.py`, `requirements.txt`, dan
   `sample_data.csv` ikut ter-push).
2. Buka [streamlit.io/cloud](https://streamlit.io/cloud), login dengan akun
   GitHub.
3. Klik **New app**, pilih repository ini, branch `main`, dan file utama
   `app.py`.
4. Klik **Deploy**. Tunggu proses build selesai.

## Link Aplikasi Streamlit yang Aktif

[ISI LINK STREAMLIT CLOUD KAMU DI SINI SETELAH DEPLOY]

## Struktur File

```
├── app.py                     # Aplikasi utama Streamlit
├── generate_sample_data.py    # Script pembuat data contoh
├── sample_data.csv            # Data contoh gerai kopi (dummy)
├── requirements.txt           # Daftar dependency
└── README.md                  # Dokumentasi proyek
```
